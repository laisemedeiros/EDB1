#include <iostream>
#include "Lista.h"

int main()
{
    Lista l;

    std::cout << "Tamanho " << l.tamanho() << std::endl;

    return 0;
}